import express from 'express';
import { getMovies, createMovie, updateMovie, deleteMovie } from '../controllers/movieController.js';
import { verifyToken, verifyAdmin } from '../middleware/auth.js';

const router = express.Router();

router.get('/', getMovies);
router.post('/', verifyToken, verifyAdmin, createMovie);
router.put('/:id', verifyToken, verifyAdmin, updateMovie);
router.delete('/:id', verifyToken, verifyAdmin, deleteMovie);

export default router;